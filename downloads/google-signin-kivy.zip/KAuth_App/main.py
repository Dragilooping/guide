import os
from kivy.lang.builder import Builder
from kivy.metrics import dp
from kivy.uix.image import AsyncImage
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.anchorlayout import AnchorLayout
from kivy.uix.widget import Widget
from kivy import platform
from kivy.clock import Clock,mainthread
from kivy.app import App

from google_auth import initialize_google, login_google, logout_google, auto_google



GOOGLE_CLIENT_ID="put your client id here"
if platform == "android":
    from android.runnable import run_on_ui_thread
    from jnius import autoclass, cast

    Toast = autoclass("android.widget.Toast")
    String = autoclass("java.lang.String")
    CharSequence = autoclass("java.lang.CharSequence") 
    PythonActivity = autoclass("org.kivy.android.PythonActivity")
    context = PythonActivity.mActivity

    @run_on_ui_thread
    def show_toast(text):
        t = Toast.makeText(
            context, cast(CharSequence, String(text)), Toast.LENGTH_SHORT
        )
        t.show()

    


kv = """
ScreenManager:
    LoginScreen:
        id: login_screen
    HomeScreen:
        id: home_screen

<LoginScreen>:
    name: "loginscreen"
    BoxLayout:
        orientation: "vertical"
        spacing: dp(20)
        padding: dp(20)

        Label:
            text: "Kivy Google Sign-In Demo"
            size_hint_y: None
            height: dp(50)
            font_size: dp(20)

        Widget:
            size_hint_y: None
            height: dp(50)

        Button:
            text: "Sign In with Google"
            size_hint: None, None
            size: dp(250), dp(50)
            pos_hint:{'center_x':0.5}
            background_color: 66/255, 133/255, 244/255, 1
            color: 1, 1, 1, 1
            on_release: app.gl_login()

        Widget:
            size_hint_y: None
            height: dp(100)

<HomeScreen>:
    name: "homescreen"
    BoxLayout:
        orientation: "vertical"
        spacing: dp(20)
        padding: dp(20)

        Label:
            id: user_name
            text: ""
            font_size: dp(20)

        AnchorLayout:
            id: user_photo

        Label:
            id: user_email
            text: ""

        Button:
            text: "LOGOUT"
            size_hint: None, None
            size: dp(200), dp(50)
            pos_hint:{'center_x':0.5}
            on_release: app.logout_()
"""

class LoginScreen(Screen):
    pass

class HomeScreen(Screen):
    pass

class LoginDemo(App):
    current_provider = ""

    def build(self):
        initialize_google(
            self.after_login,
            self.error_listener,
            GOOGLE_CLIENT_ID,
        )

        return Builder.load_string(kv)

    def on_start(self):
        if platform == "android":
            auto_google()
        pass

    def gl_login(self, *args):
        login_google()
        

    def logout_(self):
        logout_google(self.after_logout)

    @mainthread
    def after_login(self, name, email, photo_uri):
        if platform == "android":
            show_toast("Logged in with Google")
        self.root.current = "homescreen"
        self.update_ui(name, email, photo_uri)

    @mainthread
    def after_logout(self):
        self.update_ui("", "", "")
        self.root.current = "loginscreen"
        if platform == "android":
            show_toast("Logged out from Google")

    def update_ui(self, name, email, photo_uri):
        home = self.root.ids.home_screen
        home.ids.user_photo.clear_widgets()
        if photo_uri:
            home.ids.user_photo.add_widget(
                AsyncImage(source=photo_uri, size_hint=(None, None), height=dp(60), width=dp(60))
            )
        home.ids.user_name.text = f"Welcome, {name}" if name else ""
        home.ids.user_email.text = f"Your Email: {email}" if email else "Email not available"

    def error_listener(self):
        if platform == "android":
            show_toast("Error logging in.")
        Clock.schedule_once(lambda *args: None)


if __name__ == "__main__":
    LoginDemo().run()

